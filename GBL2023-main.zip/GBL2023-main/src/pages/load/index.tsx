import LoadingPage from "@/components/loading"

const InfinityLoadPage = () => {
    return <LoadingPage msg="무한 로딩(Test)"></LoadingPage>
}

export default InfinityLoadPage;